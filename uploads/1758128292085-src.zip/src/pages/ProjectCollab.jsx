import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { io } from 'socket.io-client';
import { getTasksByProject, createTask, updateTask, deleteTask } from '../services/taskService';
import { getDeliverablesByProject, uploadDeliverable } from '../services/deliverableService';
import { getMessagesByProject, createMessage } from '../services/messageService';
import { toast } from 'react-toastify';

const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || 'http://localhost:5001';

const ProjectCollab = () => {
  const { projectId } = useParams();
  const socketRef = useRef(null);

  const [tasks, setTasks] = useState([]);
  const [deliverables, setDeliverables] = useState([]);
  const [messages, setMessages] = useState([]);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newMessageContent, setNewMessageContent] = useState('');
  const [file, setFile] = useState(null);

  const fetchData = useCallback(async () => {
    try {
      const [tasksRes, deliverablesRes, messagesRes] = await Promise.all([
        getTasksByProject(projectId),
        getDeliverablesByProject(projectId),
        getMessagesByProject(projectId),
      ]);
      setTasks(tasksRes.data || []);
      setDeliverables(deliverablesRes.data || []);
      setMessages(messagesRes.data || []);
    } catch (error) {
      toast.error('Failed to load project data.');
      console.error("Fetch Data Error:", error);
    }
  }, [projectId]);

  useEffect(() => {
    fetchData();

    if (!socketRef.current) {
      console.log("Connecting to socket server...");
      socketRef.current = io(SOCKET_URL, {
        transports: ["websocket"],
        withCredentials: true,
        reconnection: true,
        reconnectionAttempts: 5,
        reconnectionDelay: 2000,
      });

      const socket = socketRef.current;

      socket.on("connect", () => {
        console.log("Socket connected!", socket.id);
        socket.emit("joinProject", { projectId });
      });

      socket.on("newMessage", (message) => {
        setMessages((prevMessages) => [...prevMessages, message]);
      });

      socket.on("connect_error", (err) => {
        console.error("Socket connection error:", err.message);
        toast.error("Could not connect to chat server.");
      });
    }

    return () => {
      if (socketRef.current) {
        console.log("Cleaning up socket connection...");
        socketRef.current.disconnect();
        socketRef.current = null;
      }
    };
  }, [projectId, fetchData]);

  // --- Task Handlers ---
  const handleAddTask = async () => {
    if (!newTaskTitle.trim()) return;
    try {
      const res = await createTask({ project: projectId, title: newTaskTitle });
      setTasks([...tasks, res.data]);
      setNewTaskTitle('');
      toast.success('Task added!');
    } catch {
      toast.error('Failed to add task.');
    }
  };

  const handleUpdateTask = async (taskId, status) => {
    try {
      const res = await updateTask(taskId, { status });
      setTasks(tasks.map((task) => (task._id === taskId ? res.data : task)));
      toast.success(`Task marked as ${status}!`);
    } catch {
      toast.error('Failed to update task.');
    }
  };

  const handleDeleteTask = async (taskId) => {
    try {
      await deleteTask(taskId);
      setTasks(tasks.filter((task) => task._id !== taskId));
      toast.success('Task deleted!');
    } catch {
      toast.error('Failed to delete task.');
    }
  };

  // --- Deliverables ---
  const handleUploadDeliverable = async () => {
    if (!file) {
      toast.warn('Please select a file to upload.');
      return;
    }
    const formData = new FormData();
    formData.append('file', file);
    formData.append('project', projectId);

    try {
      const res = await uploadDeliverable(formData);
      setDeliverables([...deliverables, res.data]);
      setFile(null);
      toast.success('Deliverable uploaded!');
    } catch {
      toast.error('Failed to upload deliverable.');
    }
  };

  // --- Chat ---
  const handleSendMessage = async () => {
    if (!newMessageContent.trim() || !socketRef.current) return;
    try {
      const messagePayload = { project: projectId, content: newMessageContent };
      const res = await createMessage(messagePayload);
      socketRef.current.emit("sendMessage", { projectId, message: res.data });
      setMessages((prev) => [...prev, res.data]);
      setNewMessageContent('');
    } catch {
      toast.error('Failed to send message.');
    }
  };

  return (
    <div className="container mx-auto p-4 md:p-8">
      <h1 className="text-3xl font-bold mb-6 text-gray-800">Project Collaboration</h1>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Tasks */}
        <div className="bg-white border p-4 rounded-lg shadow-sm lg:col-span-2">
          <h2 className="text-xl font-semibold mb-4 text-gray-700">Tasks</h2>
          <div className="flex mb-4 gap-2">
            <input
              type="text"
              className="border p-2 w-full rounded-md focus:ring-2 focus:ring-indigo-500"
              placeholder="Add a new task..."
              value={newTaskTitle}
              onChange={(e) => setNewTaskTitle(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAddTask()}
            />
            <button className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700" onClick={handleAddTask}>
              Add
            </button>
          </div>
          <ul className="space-y-2">
            {tasks.map((task) => (
              <li key={task._id} className="flex justify-between items-center p-2 rounded-md bg-gray-50 hover:bg-gray-100">
                <span className={`${task.status === 'done' ? 'line-through text-gray-500' : ''}`}>{task.title}</span>
                <div className="flex gap-2">
                  {task.status !== 'done' && (
                    <button className="text-sm text-green-600 hover:text-green-800" onClick={() => handleUpdateTask(task._id, 'done')}>Done</button>
                  )}
                  <button className="text-sm text-red-600 hover:text-red-800" onClick={() => handleDeleteTask(task._id)}>Delete</button>
                </div>
              </li>
            ))}
          </ul>
        </div>

        {/* Chat */}
        <div className="bg-white border p-4 rounded-lg shadow-sm row-start-3 lg:row-start-auto">
          <h2 className="text-xl font-semibold mb-4 text-gray-700">Chat</h2>
          <div className="border h-80 overflow-y-scroll mb-4 p-2 bg-gray-50 rounded-md flex flex-col gap-2">
            {messages.map((msg) => (
              <div key={msg._id}>
                <strong className="text-sm text-gray-800">{msg.sender?.name || 'User'}:</strong>
                <p className="text-gray-600 bg-white p-2 rounded-md">{msg.content}</p>
              </div>
            ))}
          </div>
          <div className="flex gap-2">
            <input
              type="text"
              className="border p-2 w-full rounded-md focus:ring-2 focus:ring-indigo-500"
              placeholder="Type a message..."
              value={newMessageContent}
              onChange={(e) => setNewMessageContent(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            />
            <button className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700" onClick={handleSendMessage}>Send</button>
          </div>
        </div>

        {/* Deliverables */}
        <div className="bg-white border p-4 rounded-lg shadow-sm lg:col-span-3">
          <h2 className="text-xl font-semibold mb-4 text-gray-700">Deliverables</h2>
          <div className="flex items-center gap-4">
            <input type="file" className="flex-1" onChange={(e) => setFile(e.target.files[0])} />
            <button className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700" onClick={handleUploadDeliverable}>
              Upload
            </button>
          </div>
          <ul className="mt-4 space-y-2">
            {deliverables.map((d) => (
              <li key={d._id} className="p-2 bg-gray-50 rounded-md">
                <a href={`http://localhost:5001/${d.fileUrl}`} target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:underline">
                  {d.fileUrl.split('/').pop()}
                </a>
              </li>
            ))}
          </ul>
        </div>

      </div>
    </div>
  );
};

export default ProjectCollab;
